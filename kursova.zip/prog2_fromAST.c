#include <stdio.h>
#include <stdlib.h>

int main() 
{
   int AAAAAAAAAAAAAAAA;
   int BBBBBBBBBBBBBBBB;
   int CCCCCCCCCCCCCCCC;
   printf("Enter AAAAAAAAAAAAAAAA:");
   scanf("%d", &AAAAAAAAAAAAAAAA);
   printf("Enter BBBBBBBBBBBBBBBB:");
   scanf("%d", &BBBBBBBBBBBBBBBB);
   printf("Enter CCCCCCCCCCCCCCCC:");
   scanf("%d", &CCCCCCCCCCCCCCCC);
   if (AAAAAAAAAAAAAAAA > BBBBBBBBBBBBBBBB) 
   {
   if (AAAAAAAAAAAAAAAA > CCCCCCCCCCCCCCCC) 
   {
   goto Abigger;
   }
   else
   {
   printf("%d\n", CCCCCCCCCCCCCCCC);
   goto Outofif;
Abigger:
   printf("%d\n", AAAAAAAAAAAAAAAA);
   goto Outofif;
   }
   }
   if (BBBBBBBBBBBBBBBB < CCCCCCCCCCCCCCCC) 
   {
   printf("%d\n", CCCCCCCCCCCCCCCC);
   }
   else
   {
   printf("%d\n", BBBBBBBBBBBBBBBB);
   }
Outofif:
   if (((AAAAAAAAAAAAAAAA == BBBBBBBBBBBBBBBB && AAAAAAAAAAAAAAAA == CCCCCCCCCCCCCCCC) && BBBBBBBBBBBBBBBB == CCCCCCCCCCCCCCCC)) 
   {
   printf("%d\n", 1);
   }
   else
   {
   printf("%d\n", 0);
   }
   if (((AAAAAAAAAAAAAAAA < 0 || BBBBBBBBBBBBBBBB < 0) || CCCCCCCCCCCCCCCC < 0)) 
   {
   printf("%d\n", (0 - 1));
   }
   else
   {
   printf("%d\n", 0);
   }
   if (!(AAAAAAAAAAAAAAAA < (BBBBBBBBBBBBBBBB + CCCCCCCCCCCCCCCC))) 
   {
   printf("%d\n", 10);
   }
   else
   {
   printf("%d\n", 0);
   }
   system("pause");
    return 0;
}
